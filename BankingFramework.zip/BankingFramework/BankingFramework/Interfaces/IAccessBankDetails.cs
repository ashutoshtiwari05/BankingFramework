﻿using BankingFramework.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingFramework.Interfaces
{
    public interface IAccessBankDetails
    {
        List<StandardBankFormat> GetBankDetails(string filePath);
    }
}
