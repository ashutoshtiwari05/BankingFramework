﻿using BankingFramework.Controllers;
using BankingFramework.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingFramework
{

    enum BankNames
    {
        Axis,
        HDFC,
        ICICI,
        IDFC
    }
    class Program
    {
        static void Main(string[] args)
        {
            AccessBankDetails _accessBankDetails;
            Dictionary<BankNames, string> bankDetailsWithFilePath = new Dictionary<BankNames, string>();
            try
            {
                bankDetailsWithFilePath.Add(BankNames.Axis, ".\\InputData\\Axis-Input-Case3.csv");
                bankDetailsWithFilePath.Add(BankNames.HDFC, ".\\InputData\\HDFC-Input-Case1.csv");
                // bankDetailsWithFilePath.Add("ICICI", ".\\InputData\\ICICI-Input-Case3.csv");
                //bankDetailsWithFilePath.Add("IDFC", ".\\InputData\\IDFC-Input-Case3.csv");

                List<StandardBankFormat> finalList = new List<StandardBankFormat>();
                foreach (var banks in bankDetailsWithFilePath.Keys)
                {
                    switch (banks)
                    {
                        case BankNames.Axis :
                            _accessBankDetails = new AccessBankDetails(new AxisBankController());
                            var axisBankDetails = _accessBankDetails.ExtractBankDetailsFromFile(bankDetailsWithFilePath[BankNames.Axis]);
                            finalList.AddRange(axisBankDetails);
                            break;
                        case BankNames.HDFC:
                            _accessBankDetails = new AccessBankDetails(new HdfcController());
                            var hdfcBankDetails = _accessBankDetails.ExtractBankDetailsFromFile(bankDetailsWithFilePath[BankNames.HDFC]);
                            finalList.AddRange(hdfcBankDetails);
                            break;

                    }

                }
                string fileName = "StandardReport.xlsx";
                string location = "C:\\Users\\astiwari\\Desktop\\";
                string customExcelSavingPath = location + fileName;
                DataTable dtStandardReport = Utility.ConvertToDataTable(finalList);
                Utility.GenerateExcel(dtStandardReport, customExcelSavingPath);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.Read();
        }
    }
}
