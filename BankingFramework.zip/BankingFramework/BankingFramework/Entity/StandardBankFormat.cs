﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingFramework.Entity
{
    public class StandardBankFormat
    {
        public string Date        {get; set;}
        public string TransactionDescription   {get; set;}
        public string Description   {get; set;}
        public string Debit         {get; set;}
        public string Credit        {get; set;}
        public string Currency      {get; set;}
        public string CardName      {get; set;}
        public string Transaction   {get; set;}
        public string Location { get; set; }

    }
}
