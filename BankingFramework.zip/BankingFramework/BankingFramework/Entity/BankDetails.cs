﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingFramework.Entity
{
    public class BankDetails
    {
        string BankName { get; set; }
        DateTime Date { get; set; }
        string TransactionDescription { get; set; }

        decimal TransactionAmount { get; set; }

        string TransactionBy { get; set; }
        
        string TypeOfTransaction { get; set; }

        bool IsCredit { get; set; }

        bool IsDebit { get; set; }
    }
}
