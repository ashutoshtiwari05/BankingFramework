﻿namespace BankingFramework.Controllers
{
    public static class Constants
    {
        internal static readonly char CommaSeparator = ',';
        internal static readonly string InternationalTravel = "International Transactions";
        internal static readonly string DomesticTraval = "Domestic Transactions";
        internal static readonly string DateHeader = "Date";
        internal static readonly string IndianCurrency = "INR";
        internal static readonly string Credit = "cr";
        internal const string International = "international";
        internal const string Domestic = "domestic";
    }
}