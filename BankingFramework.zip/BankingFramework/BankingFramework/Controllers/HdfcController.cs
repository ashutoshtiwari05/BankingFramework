﻿using BankingFramework.Entity;
using BankingFramework.Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingFramework.Controllers
{
    internal class HdfcController : IAccessBankDetails
    {
        public List<StandardBankFormat> GetBankDetails(string filePath)
        {
            List<StandardBankFormat> lstBankFormat = new List<StandardBankFormat>();
            List<string[]> axisBankDetails = Utility.Import(filePath, Constants.CommaSeparator, false);
            string typeOfTravel = Constants.Domestic;
            string userName = string.Empty;

            foreach (var axisBank in axisBankDetails)
            {
                var ltaxisBank = new List<string>(axisBank);
                if (ltaxisBank.Any(e => e == Constants.InternationalTravel) || ltaxisBank.Any(e => e == Constants.DomesticTraval))
                {
                    typeOfTravel = ltaxisBank.Any(e => e == Constants.InternationalTravel) ? Constants.International : Constants.Domestic;
                }
                else if (string.IsNullOrEmpty(ltaxisBank[0]) && !string.IsNullOrEmpty(ltaxisBank[1]) && ltaxisBank.Any()) // this is to get name of user
                {
                    userName = ltaxisBank[1];
                }
                else if (!string.IsNullOrEmpty(ltaxisBank[0]) && ltaxisBank[0].Trim() != Constants.DateHeader)
                {
                    StandardBankFormat bankFormat = GetBankTransaction(ltaxisBank, userName, typeOfTravel);
                    if (bankFormat != null)
                        lstBankFormat.Add(bankFormat);
                }
            }

            return lstBankFormat;
        }

        private StandardBankFormat GetBankTransaction(List<string> hdfcBankRecord, string userName, string typeOfTravel)
        {
            StandardBankFormat sBF = new StandardBankFormat();
            string[] formats = { "dd-MM-yyyy", "dd/MM/yyyy" };
            bool isValidDate = DateTime.TryParseExact(hdfcBankRecord[0], formats, DateTimeFormatInfo.InvariantInfo, DateTimeStyles.None, out DateTime extractedDate);
            if (isValidDate)
            {
                sBF.CardName = userName;
                sBF.Transaction = typeOfTravel;
                if (hdfcBankRecord.Count == 3)
                {
                    Console.WriteLine(hdfcBankRecord[0]);
                    sBF.Date = extractedDate.ToShortDateString();
                    if(hdfcBankRecord[2].Trim().Contains(Constants.Credit))
                        sBF.Credit = hdfcBankRecord[2].Replace(Constants.Credit,"").Trim().ToString();
                    else
                        sBF.Debit = hdfcBankRecord[2].ToString();
                }

                if (typeOfTravel.Equals(Constants.Domestic))
                {
                    sBF.Location = hdfcBankRecord[1].Trim().Split(' ').Last();
                    sBF.TransactionDescription = hdfcBankRecord[1].Trim().ToString();
                    sBF.Currency = Constants.IndianCurrency;
                }
                else
                {
                    var desc = hdfcBankRecord[1].Trim().Split(' ').Select(tag => tag.Trim()).Where(tag => !string.IsNullOrEmpty(tag)).ToList();
                    var transactionDesc = desc.Take(desc.Count - 1).ToArray();
                    sBF.TransactionDescription = String.Join(" ", transactionDesc);
                    sBF.Currency = desc[desc.Count - 1];
                    sBF.Location = desc[desc.Count - 2];
                }
            }
            else
                return null;

            return sBF;
        }
    }
}
