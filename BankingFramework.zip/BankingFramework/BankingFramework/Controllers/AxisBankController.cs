﻿using BankingFramework.Entity;
using BankingFramework.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingFramework.Controllers
{
    class AxisBankController : IAccessBankDetails
    {

        public List<StandardBankFormat> GetBankDetails(string filePath)
        {
            List<StandardBankFormat> lstBankFormat = new List<StandardBankFormat>();
            List<string[]> axisBankDetails = Utility.Import(filePath, Constants.CommaSeparator, false);
            string typeOfTravel = Constants.Domestic;
            string userName = string.Empty;

            foreach (var axisBank in axisBankDetails)
            {
                var ltaxisBank = new List<string>(axisBank);
                if (ltaxisBank.Any(e => e == Constants.InternationalTravel) || ltaxisBank.Any(e => e == Constants.DomesticTraval))
                {
                    typeOfTravel = ltaxisBank.Any(e => e == Constants.InternationalTravel) ? Constants.International : Constants.Domestic;
                }
                else if (string.IsNullOrEmpty(ltaxisBank[0]) && !string.IsNullOrEmpty(ltaxisBank[2]) && ltaxisBank.Any()) // this is to get name of user
                {
                    userName = ltaxisBank[2];
                }
                else if (!string.IsNullOrEmpty(ltaxisBank[0]) && ltaxisBank[0].Trim() != Constants.DateHeader)
                {
                    StandardBankFormat bankFormat = GetBankTransaction(ltaxisBank, userName, typeOfTravel);
                    if(bankFormat != null)
                        lstBankFormat.Add(bankFormat);
                }
            }

            return lstBankFormat;
        }

        private StandardBankFormat GetBankTransaction(List<string> axisBankRecord, string userName, string typeOfTravel)
        {
            StandardBankFormat sBF = new StandardBankFormat();
            string[] formats = { "dd-MM-yyyy", "dd/MM/yyyy" };
            bool isValidDate = DateTime.TryParseExact(axisBankRecord[0], formats, DateTimeFormatInfo.InvariantInfo, DateTimeStyles.None, out DateTime extractedDate);
            if (isValidDate)
            {
                sBF.CardName = userName;
                sBF.Transaction = typeOfTravel;
                if (axisBankRecord.Count == 4)
                {
                    Console.WriteLine(axisBankRecord[0]);
                    sBF.Date = extractedDate.ToShortDateString();
                    sBF.Debit = axisBankRecord[1].ToString();
                    sBF.Credit = axisBankRecord[2].ToString();
                }

                if (typeOfTravel.Equals(Constants.Domestic))
                {
                    sBF.Location = axisBankRecord[3].Split(' ').Last();
                    sBF.TransactionDescription = axisBankRecord[3].ToString();
                    sBF.Currency = Constants.IndianCurrency;
                }
                else
                {
                    var desc = axisBankRecord[3].Split(' ').Select(tag => tag.Trim()).Where(tag => !string.IsNullOrEmpty(tag)).ToList();
                    var transactionDesc = desc.Take(desc.Count-1).ToArray();
                    sBF.TransactionDescription = String.Join(" ", transactionDesc);
                    sBF.Currency = desc[desc.Count - 1];
                    sBF.Location = desc[desc.Count - 2];
                }
            }
            else
                return null;

            return sBF;
        }
    }
}
