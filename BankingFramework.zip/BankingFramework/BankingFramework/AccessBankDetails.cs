﻿using BankingFramework.Entity;
using BankingFramework.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingFramework
{
    public class AccessBankDetails
    {
        private readonly IAccessBankDetails _bankDetails;

        public AccessBankDetails(IAccessBankDetails bankDetails)
        {
            this._bankDetails = bankDetails;
        }

        public List<StandardBankFormat> ExtractBankDetailsFromFile(string filePath)
        {
            return this._bankDetails.GetBankDetails(filePath);
        }
    }
}
